package it.car.sudoku;

public class Step {
	
	public int val;
	public int iRow;
	public int iCol;

}
