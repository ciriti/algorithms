package it.car.dynamic;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by carmeloiriti, 26/08/16.
 */
public class WiggleSubsequence {

    /**
     * https://leetcode.com/problems/wiggle-subsequence/
     */

    public static void main(String args[]){

    }

    public int wiggleMaxLength(int[] nums) {
        List<Integer> res = new ArrayList<>();
        for(int n : nums){

        }
        return res.size();
    }
}
