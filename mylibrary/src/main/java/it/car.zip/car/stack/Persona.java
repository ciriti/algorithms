package it.car.stack;

public class Persona{
	String nome;

	public Persona(String nome) {
		super();
		this.nome = nome;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return nome;
	}
	
}
