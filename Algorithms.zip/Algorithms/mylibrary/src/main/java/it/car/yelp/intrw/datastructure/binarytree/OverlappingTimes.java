package it.car.yelp.intrw.datastructure.binarytree;

//import org.joda.time.JodaTimePermission;

public class OverlappingTimes {

	/**
	 * CallStart   CallEnd
	 * 2:22:22 PM  2:22:33 PM
	 * 2:22:35 PM  2:22:42 PM
	 * 2:22:36 PM  2:22:43 PM
	 * 2:22:46 PM  2:22:54 PM
	 * 2:22:49 PM  2:27:21 PM
	 * 2:22:57 PM  2:23:03 PM
	 * 2:23:29 PM  2:23:40 PM
	 * 2:24:08 PM  2:24:14 PM
	 * 2:27:37 PM  2:39:14 PM
	 * 2:27:47 PM  2:27:55 PM
	 * 2:29:04 PM  2:29:26 PM
	 * 2:29:31 PM  2:29:43 PM
	 * 2:29:45 PM  2:30:10 PM
	 */

	public static void main(String args[]){

	}

}
