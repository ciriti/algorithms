package it.car.sudoku;

public class SquareIndex {
	
	public int rMax;
	public int rMin;
	public int cMax;
	public int cMin;
	
	public SquareIndex(int rMax, int rMin, int cMax, int cMin) {
		super();
		this.rMax = rMax;
		this.rMin = rMin;
		this.cMax = cMax;
		this.cMin = cMin;
	}
	
	

}
