package it.car.here.sort;

/**
 * Created by ciriti on 04/12/16.
 */

public interface ISort {
    void sort(int[] arr);
}
