package it.car.insparx.xsum;

public class ArrayTwoMinimumSum {
	
	//

}
